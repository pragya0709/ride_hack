import React from 'react'
import './Hero.css'
const Hero = () => {
  return (
    <div className="hero container">
      <div className="hero-text">
        <h1>One stop shop for your needs!</h1>
        <p>Our cutting edge software would bring you the best medicine in town.</p>
        <button className="btn">Explore...</button>
      </div>
    </div>
  )
}

export default Hero
